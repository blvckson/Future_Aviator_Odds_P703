package com.example.aviatorai

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val input = findViewById<EditText>(R.id.historyInput)
        val button = findViewById<Button>(R.id.analyzeButton)
        val result = findViewById<TextView>(R.id.resultText)
        button.setOnClickListener {
            val values = input.text.toString().split(',', ' ', '\n', '\t').mapNotNull { it.trim().toDoubleOrNull() }.filter { it >= 1.0 }
            val analysis = Predictor.analyze(values)
            result.text = if (analysis == null) "Please enter at least one valid multiplier (1.00 or higher)." else
                String.format(Locale.US, "Analyzer estimate: %.2fx\nConfidence score: %.0f%%\n\nThis is a statistical estimate only; it cannot know the next crash result.", analysis.prediction, analysis.confidence * 100.0)
        }
    }
}
