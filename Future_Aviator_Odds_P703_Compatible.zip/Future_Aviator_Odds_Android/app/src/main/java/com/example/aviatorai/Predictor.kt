package com.example.aviatorai

data class Result(val prediction: Double, val confidence: Double)

object Predictor {
    fun analyze(history: List<Double>): Result? {
        if (history.isEmpty()) return null
        val average = history.average()
        val recent = history.takeLast(minOf(5, history.size)).average()
        val prediction = ((average + recent) / 2.0).coerceAtLeast(1.0)
        val spread = history.map { kotlin.math.abs(it - average) }.average()
        val confidence = (1.0 / (1.0 + spread)).coerceIn(0.0, 1.0)
        return Result(prediction, confidence)
    }
}
