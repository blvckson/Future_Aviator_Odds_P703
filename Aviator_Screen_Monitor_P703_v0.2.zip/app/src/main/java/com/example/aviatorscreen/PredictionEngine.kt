package com.example.aviatorscreen

data class Estimate(val value: Double, val confidence: Double)

object PredictionEngine {
    fun estimate(history: List<Double>): Estimate? {
        if (history.size < 5) return null
        val recent = history.takeLast(20)
        val avg = recent.average()
        val median = recent.sorted()[recent.size / 2]
        val lowRate = recent.count { it < 2.0 }.toDouble() / recent.size
        val volatility = recent.map { kotlin.math.abs(it - avg) }.average()
        val raw = (avg * .35) + (median * .45) +
            ((2.0 + (1.0 - lowRate) * 2.0) * .20)
        return Estimate(raw.coerceIn(1.01, 20.0),
            (1.0 / (1.0 + volatility)).coerceIn(0.0, 1.0))
    }
}
