package com.example.aviatorscreen

import android.app.*
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.Executors

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Double>()
    private var lastValues = emptySet<Double>()
    private var overlay: TextView? = null
    private var windowManager: WindowManager? = null
    private var processing = false
    private var lastProcess = 0L
    private var scanCount = 0

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel("monitor", "Aviator Monitor",
            NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        startForeground(7, Notification.Builder(this, "monitor")
            .setContentTitle("Aviator Screen Monitor")
            .setContentText("Screen capture active")
            .setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build())
        showOverlay("Monitoring active\nWaiting for multiplier text...")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED)
            ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data")
            ?: return START_NOT_STICKY
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        startCapture()
        return START_STICKY
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels,
            PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay("AviatorMonitor",
            dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler)

        reader?.setOnImageAvailableListener({ r ->
            val now = System.currentTimeMillis()
            if (processing || now - lastProcess < 1200) {
                r.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            processing = true
            lastProcess = now
            try {
                val p = image.planes[0]
                val bmpWidth = image.width + (p.rowStride - p.pixelStride * image.width) / p.pixelStride
                val bitmap = Bitmap.createBitmap(bmpWidth, image.height, Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(p.buffer)
                image.close()
                executor.execute {
                    scan(bitmap)
                    bitmap.recycle()
                    processing = false
                }
            } catch (_: Exception) {
                image.close()
                processing = false
                update("Capture error\nRetrying...")
            }
        }, handler)
    }

    private fun scan(bitmap: Bitmap) {
        scanCount++
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener(executor) { result ->
                val normalized = result.text.replace(',', '.')
                val found = Regex("""(?<![0-9])([0-9]{1,4}(?:\.[0-9]{1,2})?)\s*x\b""",
                    RegexOption.IGNORE_CASE)
                    .findAll(normalized)
                    .mapNotNull { it.groupValues[1].toDoubleOrNull() }
                    .filter { it >= 1.0 && it <= 10000.0 }
                    .toList()
                if (found.isNotEmpty()) {
                    val newOnes = found.filter { it !in lastValues }
                    if (newOnes.isNotEmpty()) {
                        history.addAll(newOnes)
                        if (history.size > 100)
                            history.subList(0, history.size - 100).clear()
                        lastValues = found.toSet()
                    }
                }
                val est = PredictionEngine.estimate(history)
                if (est == null) {
                    update("Monitoring active\nScans: $scanCount\nMultipliers: ${history.size}\nWaiting for 5 detected rounds")
                } else {
                    update(String.format(Locale.US,
                        "Monitoring active\nScans: %d\nRounds: %d\nEstimate: %.2fx\nHeuristic confidence: %.0f%%",
                        scanCount, history.size, est.value, est.confidence * 100))
                }
            }
            .addOnFailureListener(executor) {
                update("Monitoring active\nScans: $scanCount\nOCR error; retrying...")
            }
    }

    private fun showOverlay(text: String) {
        if (!Settings.canDrawOverlays(this)) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            this.text = text
            textSize = 14f
            setPadding(18, 12, 18, 12)
            setTextColor(Color.WHITE)
            setBackgroundColor(0xCC222222.toInt())
        }
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT)
        params.gravity = Gravity.TOP or Gravity.END
        params.x = 8; params.y = 120
        windowManager?.addView(overlay, params)
    }

    private fun update(text: String) {
        handler.post { overlay?.text = text }
    }

    override fun onDestroy() {
        overlay?.let { windowManager?.removeView(it) }
        display?.release(); reader?.close(); projection?.stop()
        executor.shutdownNow()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}
