package com.example.aviatorscreen

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())
    private val history = mutableListOf<Double>()
    private var lastValues = emptySet<Double>()
    private var overlay: TextView? = null
    private var windowManager: WindowManager? = null
    private var processing = false
    private var lastProcess = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = Notification.Builder(this, "monitor")
            .setContentTitle("Aviator Screen Monitor")
            .setContentText("Reading visible multipliers")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        startForeground(7, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        startCapture()
        showOverlay()
        return START_STICKY
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        val width = dm.widthPixels
        val height = dm.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay(
            "AviatorMonitor", width, height, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
        reader?.setOnImageAvailableListener({ r ->
            val now = System.currentTimeMillis()
            if (processing || now - lastProcess < 1000) {
                r.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            processing = true
            lastProcess = now
            val image = r.acquireLatestImage() ?: run { processing = false; return@setOnImageAvailableListener }
            try {
                val planes = image.planes
                val buffer = planes[0].buffer
                val pixelStride = planes[0].pixelStride
                val rowStride = planes[0].rowStride
                val rowPadding = rowStride - pixelStride * image.width
                val bmpWidth = image.width + rowPadding / pixelStride
                val bitmap = Bitmap.createBitmap(bmpWidth, image.height, Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(buffer)
                image.close()
                executor.execute {
                    try { scan(bitmap) } finally { bitmap.recycle(); processing = false }
                }
            } catch (e: Exception) {
                image.close()
                processing = false
            }
        }, handler)
    }

    private fun scan(bitmap: Bitmap) {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener(executor) { result ->
                val found = Regex("""(?<![0-9])([0-9]{1,3}(?:\.[0-9]{1,2})?)x""")
                    .findAll(result.text)
                    .mapNotNull { it.groupValues[1].toDoubleOrNull() }
                    .filter { it >= 1.0 && it <= 10000.0 }
                    .toSet()
                if (found.isNotEmpty()) {
                    val newOnes = found - lastValues
                    if (newOnes.isNotEmpty()) {
                        history.addAll(newOnes)
                        if (history.size > 100) history.subList(0, history.size - 100).clear()
                        lastValues = found
                        val est = PredictionEngine.estimate(history)
                        val text = if (est == null) {
                            "Detected ${history.size} multipliers\nNeed 5+ rounds"
                        } else {
                            String.format(Locale.US, "Estimate %.2fx\nConfidence %.0f%%\nObserved %d",
                                est.value, est.confidence * 100.0, history.size)
                        }
                        handler.post { overlay?.text = text }
                    }
                }
            }
            .addOnFailureListener(executor) { }
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = TextView(this).apply {
            text = "Aviator monitor\nStarting..."
            textSize = 14f
            setPadding(18, 12, 18, 12)
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xCC222222.toInt())
        }
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.END
        params.x = 8
        params.y = 120
        windowManager?.addView(overlay, params)
    }

    override fun onDestroy() {
        overlay?.let { windowManager?.removeView(it) }
        display?.release()
        reader?.close()
        projection?.stop()
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("monitor", "Aviator Monitor", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
