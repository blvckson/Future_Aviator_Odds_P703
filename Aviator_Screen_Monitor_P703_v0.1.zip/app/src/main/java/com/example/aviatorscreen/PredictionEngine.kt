package com.example.aviatorscreen

import kotlin.math.abs

data class Estimate(val value: Double, val confidence: Double)

object PredictionEngine {
    fun estimate(history: List<Double>): Estimate? {
        if (history.size < 5) return null
        val recent = history.takeLast(20)
        val avg = recent.average()
        val sorted = recent.sorted()
        val median = sorted[sorted.size / 2]
        val lowRate = recent.count { it < 2.0 }.toDouble() / recent.size
        val volatility = recent.map { abs(it - avg) }.average()

        // Heuristic estimate only. It is NOT a probability or a guaranteed next result.
        val raw = (avg * 0.35) + (median * 0.45) + ((2.0 + (1.0 - lowRate) * 2.0) * 0.20)
        val value = raw.coerceIn(1.01, 20.0)
        val confidence = (1.0 / (1.0 + volatility)).coerceIn(0.0, 1.0)
        return Estimate(value, confidence)
    }
}
